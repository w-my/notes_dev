#include <Foundation/NSFileVersion.h>

@implementation NSFileVersion
@end
