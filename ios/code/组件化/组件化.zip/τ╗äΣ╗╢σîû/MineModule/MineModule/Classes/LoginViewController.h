//
//  LoginViewController.h
//  CTMediator
//
//  Created by WTW on 2019/10/29.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
