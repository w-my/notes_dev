//
//  MineViewController.h
//  MainProject
//
//  Created by WTW on 2019/10/28.
//  Copyright © 2019 WTW. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MineViewController : UIViewController

@property (nonatomic,copy) NSString *title;
@property (nonatomic,strong) UIImage *image;

@end

NS_ASSUME_NONNULL_END
