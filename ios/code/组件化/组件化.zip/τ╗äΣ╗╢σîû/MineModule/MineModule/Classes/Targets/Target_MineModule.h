//
//  Target_MineModule.h
//  MineModule
//
//  Created by WTW on 2019/10/29.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Target_MineModule : NSObject
- (UIViewController *)Action_Mine_viewController:(NSDictionary *)params;
@end

NS_ASSUME_NONNULL_END
