# MineModule

[![CI Status](https://img.shields.io/travis/wutengwei/MineModule.svg?style=flat)](https://travis-ci.org/wutengwei/MineModule)
[![Version](https://img.shields.io/cocoapods/v/MineModule.svg?style=flat)](https://cocoapods.org/pods/MineModule)
[![License](https://img.shields.io/cocoapods/l/MineModule.svg?style=flat)](https://cocoapods.org/pods/MineModule)
[![Platform](https://img.shields.io/cocoapods/p/MineModule.svg?style=flat)](https://cocoapods.org/pods/MineModule)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MineModule is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MineModule'
```

## Author

wutengwei, wutengwei@rocedar.com

## License

MineModule is available under the MIT license. See the LICENSE file for more info.
