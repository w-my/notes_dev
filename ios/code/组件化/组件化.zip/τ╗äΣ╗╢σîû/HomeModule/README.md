# HomeModule

[![CI Status](https://img.shields.io/travis/wutengwei/HomeModule.svg?style=flat)](https://travis-ci.org/wutengwei/HomeModule)
[![Version](https://img.shields.io/cocoapods/v/HomeModule.svg?style=flat)](https://cocoapods.org/pods/HomeModule)
[![License](https://img.shields.io/cocoapods/l/HomeModule.svg?style=flat)](https://cocoapods.org/pods/HomeModule)
[![Platform](https://img.shields.io/cocoapods/p/HomeModule.svg?style=flat)](https://cocoapods.org/pods/HomeModule)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

HomeModule is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'HomeModule'
```

## Author

wutengwei, wutengwei@rocedar.com

## License

HomeModule is available under the MIT license. See the LICENSE file for more info.
