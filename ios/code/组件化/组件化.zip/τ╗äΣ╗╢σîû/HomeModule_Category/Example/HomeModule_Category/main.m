//
//  main.m
//  HomeModule_Category
//
//  Created by wutengwei on 10/28/2019.
//  Copyright (c) 2019 wutengwei. All rights reserved.
//

@import UIKit;
#import "TWAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TWAppDelegate class]));
    }
}
