//
//  CTMediator+MineModule.h
//  CTMediator
//
//  Created by WTW on 2019/10/29.
//

#import <UIKit/UIKit.h>

#import <CTMediator/CTMediator.h>

NS_ASSUME_NONNULL_BEGIN

@interface CTMediator (MineModule)
- (UIViewController *)MineModule_Mine_ViewControler:(NSDictionary *)params;
@end

NS_ASSUME_NONNULL_END
