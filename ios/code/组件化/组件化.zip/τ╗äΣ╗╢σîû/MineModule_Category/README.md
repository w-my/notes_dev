# MineModule_Category

[![CI Status](https://img.shields.io/travis/wutengwei/MineModule_Category.svg?style=flat)](https://travis-ci.org/wutengwei/MineModule_Category)
[![Version](https://img.shields.io/cocoapods/v/MineModule_Category.svg?style=flat)](https://cocoapods.org/pods/MineModule_Category)
[![License](https://img.shields.io/cocoapods/l/MineModule_Category.svg?style=flat)](https://cocoapods.org/pods/MineModule_Category)
[![Platform](https://img.shields.io/cocoapods/p/MineModule_Category.svg?style=flat)](https://cocoapods.org/pods/MineModule_Category)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MineModule_Category is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MineModule_Category'
```

## Author

wutengwei, wutengwei@rocedar.com

## License

MineModule_Category is available under the MIT license. See the LICENSE file for more info.
