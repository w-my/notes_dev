//
//  TWViewController.m
//  MineModule_Category
//
//  Created by wutengwei on 10/29/2019.
//  Copyright (c) 2019 wutengwei. All rights reserved.
//

#import "TWViewController.h"

@interface TWViewController ()

@end

@implementation TWViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
